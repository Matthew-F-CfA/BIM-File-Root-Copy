package bim.copyAllByExtensions;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.FileSystems;
import java.nio.file.FileSystem;
import static java.nio.file.StandardCopyOption.*;
import javax.swing.JFileChooser;

/*
//For deleting temporary directory on jvm exit:
Path tmp = Files.createTempDirectory(null);
tmp.toFile().deleteOnExit();
*/

public class FrameMain extends Frame
implements ActionListener {
  static volatile boolean blnTest=false;

  volatile ProgressThread progressThr=new ProgressThread();
  static volatile String strCurrentFileCopy="";
  static volatile long lngProgressDelay=2500l;

  volatile List lstExtensions=new List(5);
  volatile Button btnRemoveExtension=new Button("Remove Extension");

  volatile TextField txtAddExtension=new TextField(10);
  volatile Button btnAddExtension=new Button("Add Extension");

  volatile List lstRootsCopyFrom=new List(5);
  volatile Button btnChooseRootFrom=new Button("Choose Root");
  volatile Label lblRootFrom=new Label("                         ");

//volatile List lstRootsCopyTo=new List(5);
  volatile Button btnChooseTo=new Button("Choose Transfer To Folder");
  volatile Label lblTo=new Label("                         ");

  volatile Button btnExecuteCopy=new Button("Execute Copy");

  volatile TextArea txtStatus=new TextArea(10, 100);

  static volatile String fSep="";

  public static void main(String args[]) {
    if(args.length==0) {
      blnTest=false;
    }
    else if(args.length==1) {
      blnTest=Boolean.valueOf(args[0]).booleanValue();
    }
    else {
      System.out.println("Usage:");
      System.out.println("  java bim.copyAllByExtensions.FrameMain <testing boolean>");

      return;
    }

    FrameMain mFrame=new FrameMain();

    try {
      File fRoots[]=File.listRoots();

      for(int i=0;i<fRoots.length;i++) {
        String strRoot=fRoots[i].getAbsolutePath();

        mFrame.lstRootsCopyFrom.add(strRoot);

//        mFrame.lstRootsCopyTo.add(strRoot);
      }
    }
    catch(Exception ex) {
      ex.printStackTrace();

      return;
    }

    fSep=System.getProperty("file.separator");

    Dimension dimScreen=Toolkit.getDefaultToolkit().getScreenSize();

    mFrame.setSize(dimScreen.width, dimScreen.height-50);
    mFrame.setVisible(true);

    mFrame.progressThr.start();

    mFrame.lblRootFrom.setText("");
    mFrame.lblTo.setText("");
  }

  public FrameMain() {
    super();

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
        System.exit(0);
      }
    });

    Panel pnlNorth=new Panel();
    pnlNorth.setLayout(new BorderLayout());

    Panel pnlNorthA=new Panel();
    pnlNorthA.setLayout(new BorderLayout());
    Panel pnlNorthA1=new Panel();
    pnlNorthA1.setLayout(new BorderLayout());
    pnlNorthA1.add("North", lstExtensions);
    pnlNorthA1.add("Center", new Label(""));
    pnlNorthA1.add("South", btnRemoveExtension);
    btnRemoveExtension.addActionListener(this);
    pnlNorthA.add("North", pnlNorthA1);
    pnlNorthA.add("Center", new Label(""));
    Panel pnlNorthA2=new Panel();
    pnlNorthA2.setLayout(new BorderLayout());
    pnlNorthA2.add("West", new Label("Extension to Add:"));
    pnlNorthA2.add("Center", txtAddExtension);
    pnlNorthA2.add("East", btnAddExtension);
    btnAddExtension.addActionListener(this);
    pnlNorthA.add("South", pnlNorthA2);

    pnlNorth.add("North", pnlNorthA);

    Panel pnlNorthB=new Panel();
    pnlNorthB.setLayout(new BorderLayout());
    Panel pnlNorthB1=new Panel();
    pnlNorthB1.setLayout(new GridLayout(1, 2));

    Panel pnlNorthB1A=new Panel();
    pnlNorthB1A.setLayout(new BorderLayout());
    pnlNorthB1A.add("North", new Label("Copy From:"));
    pnlNorthB1A.add("Center", lstRootsCopyFrom);
    Panel pnlNorthB1A1=new Panel();
    pnlNorthB1A1.setLayout(new GridLayout(2, 1));
    pnlNorthB1A1.add(btnChooseRootFrom);
    btnChooseRootFrom.addActionListener(this);
    pnlNorthB1A1.add(lblRootFrom);
    pnlNorthB1A.add("South", pnlNorthB1A1);

    pnlNorthB1.add(pnlNorthB1A);



//  Button btnChooseTo=new Button("Choose Transfer To Folder");
//  Label lblTo=new Label("                         ");


    Panel pnlNorthB1B=new Panel();
    pnlNorthB1B.setLayout(new BorderLayout());
    pnlNorthB1B.add("North", new Label("Copy To:"));
    pnlNorthB1B.add("Center", new Label(""));
//    pnlNorthB1B.add("Center", lstRootsCopyTo);
    Panel pnlNorthB1B1=new Panel();
    pnlNorthB1B1.setLayout(new GridLayout(2, 1));
    pnlNorthB1B1.add(btnChooseTo);
    btnChooseTo.addActionListener(this);
    pnlNorthB1B1.add(lblTo);
    pnlNorthB1B.add("South", pnlNorthB1B1);

    pnlNorthB1.add(pnlNorthB1B);


    pnlNorthB.add("North", pnlNorthB1);

    pnlNorthB.add("Center", new Label(""));

    pnlNorthB.add("South", btnExecuteCopy);
    btnExecuteCopy.addActionListener(this);

    pnlNorth.add("Center", new Label(""));

    pnlNorth.add("South", pnlNorthB);

    add("North", pnlNorth);

    add("Center", txtStatus);
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==btnRemoveExtension) {
      int intSelectedIndex=lstExtensions.getSelectedIndex();

      if(intSelectedIndex==-1)
        return;

      lstExtensions.remove(intSelectedIndex);
    }
    else if(evSource==btnAddExtension) {
      String strExtension=txtAddExtension.getText();

      if(strExtension.length()==0)
        return;

      if(strExtension.indexOf(".")!=-1) {
        txtStatus.append("\nError. You can't enter \".\" in extension.");

        return;
      }

      if(strExtension.indexOf(fSep)!=-1) {
        txtStatus.append("\nError. You can't enter file separator \""+fSep+"\" in extension.");

        return;
      }

      lstExtensions.add(strExtension);
    }
    else if(evSource==btnChooseRootFrom) {
      int intSelectedIndex=lstRootsCopyFrom.getSelectedIndex();

      if(intSelectedIndex==-1)
        return;

      String strRoot=lstRootsCopyFrom.getSelectedItem();

      lblRootFrom.setText(strRoot);

      lblTo.setText("");
    }
    else if(evSource==btnChooseTo) {
      String strRootFrom=lblRootFrom.getText();

      if(strRootFrom.length()==0) {
        txtStatus.append("\nError. You must select \"From\" path first.");

        return;
      }

//      int intSelectedIndex=lstRootsCopyTo.getSelectedIndex();

//      if(intSelectedIndex==-1)
//        return;

//      String strRoot=lstRootsCopyTo.getSelectedItem();

      JFileChooser chooser=new JFileChooser();
      chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
      int returnVal=chooser.showOpenDialog(this);
      if(returnVal!=JFileChooser.APPROVE_OPTION) {
        return;
      }

      String strTo=chooser.getSelectedFile().getAbsolutePath();

      if(strTo.startsWith(strRootFrom)) {
        txtStatus.append("\nError. The \"To\" path can't have the same root path as the \"From\" path.");

        return;
      }

      lblTo.setText(strTo);
    }
    else if(evSource==btnExecuteCopy) {
      txtStatus.setText("");

      String strExtensions[]=lstExtensions.getItems();

      if(strExtensions.length==0) {
        txtStatus.append("\nError. You must enter extensions that you want to copy.");

        return;
      }

      String strFrom=lblRootFrom.getText();
      String strTo=lblTo.getText();

      if(strFrom.length()==0) {
        txtStatus.append("\nError. You must select \"From\" path.");

        return;
      }

      if(strTo.length()==0) {
        txtStatus.append("\nError. You must select \"To\" path.");

        return;
      }

      if(strFrom.equals(strTo)) {
        txtStatus.append("\nError. The \"From\" path can't be the same as the \"To\" path.");

        return;
      }


      File fileRoots[]=File.listRoots();
      int iz=0;
      for(;iz<fileRoots.length;iz++) {
        if(fileRoots[iz].getAbsolutePath().equals(new File(strTo).getAbsolutePath())) {
          break;
        }
      }

      if(iz==fileRoots.length) {
        if(strTo.endsWith(fSep))
          strTo=strTo.substring(0, strTo.length()-fSep.length());
      }

      try {
        txtStatus.append("\nExecuting copy...");

        executeCopy(strExtensions, strFrom, strTo);

        txtStatus.append("\nCopy successful.\n\n");
      }
      catch(Exception ex) {
        txtStatus.append("\n\n"+String.valueOf(ex)+"\n\n");
        txtStatus.append("\n\nCopy failed.\n\n");

        ex.printStackTrace();
      }

      strCurrentFileCopy="";
    }
  }

  public void executeCopy(String strExtensions[], String strFrom, String strTo) throws Exception {
    int intFromLength=strFrom.length();
    int intToLength=strTo.length();

    executeFileCopy0(strExtensions, new File(strFrom), strTo, intFromLength, intToLength);
  }

  public void executeFileCopy0(String strExtensions[], File fileFrom, String strTo, int intFromLength, int intToLength) throws Exception {
    String strFromDirectory=fileFrom.getAbsolutePath();
    String strFromRelative=strFromDirectory.substring(intFromLength);

    String strToDirectory=strTo+fSep+strFromRelative;

/*
    String strToDirectory=strFromDirectory;
    strToDirectory=strToDirectory.substring(intFromLength);
    strToDirectory=strToTemp.substring(0, intToLength)+strToDirectory;
*/

    if(blnTest) {
      txtStatus.append("\nCopying from directory \""+strFromDirectory+"\" to \""+strToDirectory+"\" ...");

      Thread.sleep(5000l);
    }

/*
    if(new File(strToDirectory).exists()) {
      throw new Exception("Error. Directory \""+strToDirectory+"\" already exists in the \"To\" path. Unable to complete operation.");
    }

    new File(strToDirectory).mkdirs();
*/

    File files[]=fileFrom.listFiles();

    for(int i=0;i<files.length;i++) {
      if(files[i].isDirectory()) {

        executeFileCopy(strExtensions, files[i], strTo, intFromLength, intToLength);
      }
      else {
        String strFileFrom=files[i].getAbsolutePath();
        if(strFromDirectory.length()==intFromLength)
          strFileFrom=strFileFrom.substring(strFromDirectory.length());
        else
          strFileFrom=strFileFrom.substring(strFromDirectory.length()+fSep.length());

        int intDot=strFileFrom.lastIndexOf(".");
        if(intDot==-1)
          continue;

        String strExtension=strFileFrom.substring(intDot+1);

        int ia=0;
        for(;ia<strExtensions.length;ia++) {
          if(strExtensions[ia].equalsIgnoreCase(strExtension))
            break;
        }

        if(ia==strExtensions.length)
          continue;

        Path pathFrom=FileSystems.getDefault().getPath(strFromDirectory, strFileFrom);
        Path pathTo=FileSystems.getDefault().getPath(strToDirectory, strFileFrom);

//        String strPathFrom=strFromDirectory;
//        String strPathTo=strToDirectory;

//        Path pathFrom=FileSystems.getDefault().getPath(strPathFrom, strFileFrom);
//        Path pathTo=FileSystems.getDefault().getPath(strPathTo, strFileFrom);

        if(blnTest) {
          txtStatus.append("\nCopying file \""+strFromDirectory+fSep+strFileFrom+"\" to \""+strToDirectory+fSep+strFileFrom+"\" ...");

          Thread.sleep(5000l);
        }
        else {
          strCurrentFileCopy=strFileFrom;

          Files.copy(pathFrom, pathTo, REPLACE_EXISTING);
        }
      }
    }
  }

  public void executeFileCopy(String strExtensions[], File fileFrom, String strTo, int intFromLength, int intToLength) throws Exception {
    String strFromDirectory=fileFrom.getAbsolutePath();
    String strFromRelative=strFromDirectory.substring(intFromLength);

    String strToDirectory=strTo+fSep+strFromRelative;

/*
    String strToDirectory=strFromDirectory;
    strToDirectory=strToDirectory.substring(intFromLength);
    strToDirectory=strToTemp.substring(0, intToLength)+strToDirectory;
*/

    if(blnTest) {
      txtStatus.append("\nCopying from directory \""+strFromDirectory+"\" to \""+strToDirectory+"\" ...");

      Thread.sleep(5000l);
    }

    if(new File(strToDirectory).exists()) {
      throw new Exception("Error. Directory \""+strToDirectory+"\" already exists in the \"To\" path. Unable to complete operation.");
    }

    new File(strToDirectory).mkdirs();

    File files[]=fileFrom.listFiles();

    for(int i=0;i<files.length;i++) {
      if(files[i].isDirectory()) {

        executeFileCopy(strExtensions, files[i], strTo, intFromLength, intToLength);
      }
      else {
        String strFileFrom=files[i].getAbsolutePath();
        if(strFromDirectory.length()==intFromLength)
          strFileFrom=strFileFrom.substring(strFromDirectory.length());
        else
          strFileFrom=strFileFrom.substring(strFromDirectory.length()+fSep.length());

        int intDot=strFileFrom.lastIndexOf(".");
        if(intDot==-1)
          continue;

        String strExtension=strFileFrom.substring(intDot+1);

        int ia=0;
        for(;ia<strExtensions.length;ia++) {
          if(strExtensions[ia].equalsIgnoreCase(strExtension))
            break;
        }

        if(ia==strExtensions.length)
          continue;

        Path pathFrom=FileSystems.getDefault().getPath(strFromDirectory, strFileFrom);
        Path pathTo=FileSystems.getDefault().getPath(strToDirectory, strFileFrom);

//        String strPathFrom=strFromDirectory;
//        String strPathTo=strToDirectory;

//        Path pathFrom=FileSystems.getDefault().getPath(strPathFrom, strFileFrom);
//        Path pathTo=FileSystems.getDefault().getPath(strPathTo, strFileFrom);

        if(blnTest) {
          txtStatus.append("\nCopying file \""+strFromDirectory+fSep+strFileFrom+"\" to \""+strToDirectory+fSep+strFileFrom+"\" ...");

          Thread.sleep(5000l);
        }
        else {
          strCurrentFileCopy=strFileFrom;

          Files.copy(pathFrom, pathTo, REPLACE_EXISTING);
        }
      }
    }
  }

  class ProgressThread extends Thread {
    volatile boolean keepAlive=true;

    ProgressThread() {
      super();
    }

    public void run() {
      try {
        while(keepAlive) {
          if(strCurrentFileCopy.length()!=0)
            txtStatus.append("\nCopying file \""+strCurrentFileCopy+"\" ...");

          Thread.sleep(lngProgressDelay);
        }
      }
      catch(Exception ex) {
        ex.printStackTrace();

        System.exit(0);
      }
    }
  }
}